
package Game;

public class Roupas {
   
    
      private static class Char {

        public Char() {
        }
    }
      
    String roupas;
    String modelo;
    String cor;
    Char tamanho;
    String acessorios;
    int codigo;

    public Roupas (String roupas) {
        this.roupas = roupas;
        this.acessorios = acessorios;
    }

    public void vestido() {
        /* código do vestido */
    }

    public void macacão() {
        /* código do macacão */
    }

    public void Faixa() {
        /* código da faixa da barbie */
    }
    
    public void Chapeu(){
        /*codigo do acessorio da barbie chpaeu */
}
   public void Bolsa(){
      /*codigo chapeu da barbie*/
  }     
  
  
   
  public String getRoupas () {
    return roupas;
    }

    public void setRoupas() {
      this.roupas = roupas;
    }

    public String getModelo () {
        return modelo;
    }
    
    public void setModelo(){
        this.modelo = modelo;
    }
    
    public String getCor(){
        return cor;
    }
    
    public void setCor(){
        this.cor = cor;
    }
    
    public Char getTamanho (){
        return tamanho;
    }
    
    public void setTamanho(){
        this.tamanho = tamanho;
    }
   
    public String getAcessorios() {
        return acessorios;
    }

    public void setAcessorios() {
       this.acessorios = acessorios;
    }

    public int getCodigo(){
        return codigo;
    }
    
    public void setCodigo(){
       this.codigo = codigo; 
    }
     
}




