package Game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;
import javax.swing.ImageIcon;

public class Vestirse extends javax.swing.JFrame {

    int indiceVestido = 1;
    int indiceAcessorios = 1;
    ImageIcon icon;
    
    Color rosa = new Color(249, 0, 184);

    public Vestirse() {
        initComponents();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        setResizable(false);
        
        URL url = this.getClass().getResource("/Images/barbie.png");
        Image imgTitulo = Toolkit.getDefaultToolkit().getImage(url);
        setIconImage(imgTitulo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        botao = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        BtnVestir = new javax.swing.JButton();
        BtnAcessoriosD = new javax.swing.JButton();
        BtnAcessoriosE = new javax.swing.JButton();
        LblVestido = new javax.swing.JLabel();
        BtnRoupaE = new javax.swing.JButton();
        BtnRoupaD = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        LblAcessorios = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        jPanel3.setBackground(new java.awt.Color(255, 153, 255));
        jPanel3.setForeground(new java.awt.Color(255, 151, 255));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setText(">");
        jPanel3.add(jLabel6);

        botao.setBackground(new java.awt.Color(255, 153, 255));
        botao.setForeground(new java.awt.Color(255, 51, 255));
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoMouseClicked(evt);
            }
        });

        jLabel5.setText("<");
        botao.add(jLabel5);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 480, 230));

        BtnVestir.setBackground(new java.awt.Color(255, 204, 255));
        BtnVestir.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        BtnVestir.setForeground(new java.awt.Color(255, 255, 255));
        BtnVestir.setText("Vestir");
        BtnVestir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnVestirActionPerformed(evt);
            }
        });
        jPanel1.add(BtnVestir, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 610, 270, 70));

        BtnAcessoriosD.setBackground(new java.awt.Color(255, 204, 255));
        BtnAcessoriosD.setForeground(new java.awt.Color(255, 153, 255));
        BtnAcessoriosD.setText(">");
        BtnAcessoriosD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAcessoriosDActionPerformed(evt);
            }
        });
        jPanel1.add(BtnAcessoriosD, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 490, 70, 40));

        BtnAcessoriosE.setBackground(new java.awt.Color(255, 153, 255));
        BtnAcessoriosE.setForeground(new java.awt.Color(255, 153, 255));
        BtnAcessoriosE.setText("<");
        BtnAcessoriosE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAcessoriosEActionPerformed(evt);
            }
        });
        jPanel1.add(BtnAcessoriosE, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 490, 70, 40));

        LblVestido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LblVestido.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\roupa1vestido.png")); // NOI18N
        jPanel1.add(LblVestido, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 20, 90, 420));

        BtnRoupaE.setBackground(new java.awt.Color(255, 204, 255));
        BtnRoupaE.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnRoupaE.setForeground(new java.awt.Color(255, 153, 255));
        BtnRoupaE.setText("<");
        BtnRoupaE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRoupaEActionPerformed(evt);
            }
        });
        jPanel1.add(BtnRoupaE, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 180, 70, 40));

        BtnRoupaD.setBackground(new java.awt.Color(255, 204, 255));
        BtnRoupaD.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BtnRoupaD.setForeground(new java.awt.Color(255, 153, 255));
        BtnRoupaD.setText(">");
        BtnRoupaD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRoupaDActionPerformed(evt);
            }
        });
        jPanel1.add(BtnRoupaD, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 180, 70, 40));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/a barbie n.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 430, 540));

        LblAcessorios.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\acessorio1faixa.png")); // NOI18N
        jPanel1.add(LblAcessorios, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 440, 100, 140));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/casa da barbie.jpg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, -20, 1160, 820));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, -10, 1070, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnRoupaDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRoupaDActionPerformed
        if (indiceVestido >= 1 && indiceVestido < 2) {
            indiceVestido = indiceVestido + 1;
            System.out.println("Valor do índice de roupa: " + indiceVestido);
        }
        if (indiceVestido == 1) {
            LblVestido.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\roupa1vestido.png"));
        } else if (indiceVestido == 2) {
            LblVestido.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\roupa2macacao.png"));
        }
    }//GEN-LAST:event_BtnRoupaDActionPerformed

    private void BtnRoupaEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRoupaEActionPerformed
        if (indiceVestido > 1 && indiceVestido <= 2) {
            indiceVestido = indiceVestido - 1;
            System.out.println("Valor do índice de roupa: " + indiceVestido);
        }

        if (indiceVestido == 1) {
            LblVestido.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\roupa1vestido.png"));
        } else if (indiceVestido == 2) {
            LblVestido.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\roupa2macacao.png"));
        }
    }//GEN-LAST:event_BtnRoupaEActionPerformed

    private void botaoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoMouseClicked

        // TODO add your handling code here:
    }//GEN-LAST:event_botaoMouseClicked

    private void BtnAcessoriosDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAcessoriosDActionPerformed
        // TODO add your handling code here:
        if (indiceAcessorios >= 1 && indiceAcessorios < 3) {
            indiceAcessorios = indiceAcessorios + 1;
            System.out.println("Valor do índice de acessório: " + indiceAcessorios);
        }

        if (indiceAcessorios == 1) {
            LblAcessorios.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\acessorio1faixa.png"));
        } else if (indiceAcessorios == 2) {
            LblAcessorios.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\acessorio2chapeu.png"));
        } else if (indiceAcessorios == 3) {
            LblAcessorios.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\acessorio3bolsa.png"));
        }


    }//GEN-LAST:event_BtnAcessoriosDActionPerformed

    private void BtnAcessoriosEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAcessoriosEActionPerformed
        // TODO add your handling code here:
        if (indiceAcessorios > 1 && indiceAcessorios <= 3) {
            indiceAcessorios = indiceAcessorios - 1;
            System.out.println("Valor do índice de acessório: " + indiceAcessorios);
        }

        if (indiceAcessorios == 1) {
            LblAcessorios.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\acessorio1faixa.png"));
        } else if (indiceAcessorios == 2) {
            LblAcessorios.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\acessorio2chapeu.png"));
        } else if (indiceAcessorios == 3) {
            LblAcessorios.setIcon(new javax.swing.ImageIcon("C:\\Users\\22159716\\Documents\\NetBeansProjects\\gameBarbie\\src\\main\\resources\\Images\\acessorios3bolsa"));
        }
    }//GEN-LAST:event_BtnAcessoriosEActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        BtnVestir.setBackground(rosa);
    }//GEN-LAST:event_formWindowActivated

    private void BtnVestirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnVestirActionPerformed
        // TODO add your handling code here:
        Vestida formVestida = new Vestida();
        
        String roupa = "";
        String acessorio = "";
        String Codigo;
        
        if (indiceAcessorios == 1) {
            acessorio = "Faixa";
            formVestida.LblChapeu.setVisible(false);
            formVestida.LblBolsa.setVisible(false);
        } else if (indiceAcessorios == 2) {
            acessorio = "Chapeu";
            formVestida.LblBolsa.setVisible(false);
            formVestida.LblFaixa.setVisible(false);
        } else if (indiceAcessorios == 3) {
            acessorio = "Bolsa";
            formVestida.LblChapeu.setVisible(false);
            formVestida.LblFaixa.setVisible(false);
        }
        
        if (indiceVestido == 1){
            roupa = "Vestido";
            formVestida.LblMacacao.setVisible(false);
        }else if (indiceVestido == 2){
            roupa = "Macacão";
            formVestida.LblVestido.setVisible(false);
        }
        
        Codigo = "0" + indiceVestido + "0" + indiceAcessorios;
        
        Conectar.insertOne(roupa, acessorio, Codigo);
        
        dispose();
        
        formVestida.setVisible(true);
        
    }//GEN-LAST:event_BtnVestirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vestirse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vestirse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vestirse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vestirse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vestirse().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAcessoriosD;
    private javax.swing.JButton BtnAcessoriosE;
    private javax.swing.JButton BtnRoupaD;
    private javax.swing.JButton BtnRoupaE;
    private javax.swing.JButton BtnVestir;
    private javax.swing.JLabel LblAcessorios;
    private javax.swing.JLabel LblVestido;
    private javax.swing.JPanel botao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
