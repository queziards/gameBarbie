package Game;

import com.mongodb.*;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import static com.mongodb.client.model.Filters.eq;
import java.awt.List;
import java.io.StringWriter;
import java.util.ArrayList;
import javax.xml.transform.dom.DOMSource;
import org.bson.Document;
import java.lang.*;

public class Conectar {


    public static void insertOne(String roupa, String acessorio, String codigo) {

        try ( MongoClient mongo = new MongoClient("localhost", 27017);) {
            MongoDatabase database = mongo.getDatabase("barbie");
            MongoCollection<Document> collection = database.getCollection("roupas");
            
            
            try {
                Document doc = new Document();
                doc.put("Roupa", roupa);
                doc.put("Acessorio", acessorio);
                doc.put("Código", codigo);
                
                collection.insertOne(doc);
                
                mongo.close();
                
            } catch (MongoException me) {
                System.err.println("An error occurred: " + me);
            }
        }
    }    

}
